import org.junit.*;
import static org.junit.Assert.assertEquals;


public class ArrayTest {


}
